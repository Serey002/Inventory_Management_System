import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import { BaseController } from "./BaseController";
import { UserService } from "../services/UserService";
import { Users } from "../Entities/Users";

const SALT_ROUNDS = 12;

// ─── Validation ──────────────────────────────────────────────────────────────

const VALIDATORS = {
  create(data: Partial<Users>): string | null {
    if (!data.name || !data.email || !data.password)
      return "Name, email, and password are required";
    if ((data.password as string).length < 6)
      return "Password must be at least 6 characters";
    return null;
  },

  id(raw: string): number | null {
    const id = parseInt(raw);
    return isNaN(id) ? null : id;
  },
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

const buildUser = async (data: Partial<Users>): Promise<Users> => {
  const user = Object.assign(new Users(), data);
  user.password = await bcrypt.hash(data.password as string, SALT_ROUNDS);
  return user;
};

// ─── Controller ──────────────────────────────────────────────────────────────

export class UserController extends BaseController {
  constructor(private readonly userService: UserService) {
    super();
  }

  getAll = async (_req: Request, res: Response): Promise<void> => {
    try {
      const users = await this.userService.getAll();
      this.sendSuccess(res, users);
    } catch (error) {
      this.sendError(res, this.resolveError(error, "Failed to fetch users"), 500);
    }
  };

  create = async (req: Request, res: Response): Promise<void> => {
    const data: Partial<Users> = req.body ?? {};

    const validationError = VALIDATORS.create(data);
    if (validationError) {
      this.sendError(res, validationError);
      return;
    }

    try {
      const user = await buildUser(data);
      const created = await this.userService.createUser(user);
      this.sendCreated(res, created);
    } catch (error) {
      this.sendError(res, this.resolveError(error, "Failed to create user"), 400);
    }
  };

  update = async (req: Request, res: Response): Promise<void> => {
    const id = VALIDATORS.id(req.params.id);
    if (id === null) {
      this.sendError(res, "Invalid user ID");
      return;
    }

    try {
      const updated = await this.userService.updateUser(id, req.body);
      if (!updated) {
        this.sendError(res, "User not found", 404);
        return;
      }
      this.sendSuccess(res, updated);
    } catch (error) {
      this.sendError(res, this.resolveError(error, "Failed to update user"), 400);
    }
  };

  delete = async (req: Request, res: Response): Promise<void> => {
    const id = VALIDATORS.id(req.params.id);
    if (id === null) {
      this.sendError(res, "Invalid user ID");
      return;
    }

    try {
      const deleted = await this.userService.deleteUser(id);
      if (!deleted) {
        this.sendError(res, "User not found", 404);
        return;
      }
      this.sendSuccess(res, { message: "User deleted successfully" });
    } catch (error) {
      this.sendError(res, this.resolveError(error, "Failed to delete user"), 400);
    }
  };
}